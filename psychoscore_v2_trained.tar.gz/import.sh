#!/bin/bash
# Import trained v2 model into main project

set -e

echo "🔄 Importing PSYCHOSCORE v2 trained model..."

# Extract archive
tar -xzvf psychoscore_v2_trained.tar.gz -C .

# Move to correct location
mv lora_performance checkpoints/
if [ -d "dpo_aligned" ]; then
    mv dpo_aligned checkpoints/
fi

# Update config (manual step)
echo ""
echo "✅ Import complete!"
echo ""
echo "📝 Update config/model_selection.yaml:"
echo "   v2.lora_path: checkpoints/lora_performance"
echo ""
echo "🧪 Test with:"
echo "   python scripts/test_v2_inference.py"
